// دالة تحميل المنتجات من الخادم
async function loadProducts() {
    try {
        const response = await fetch('/api/products');
        const products = await response.json();
        renderProducts(products);
    } catch (error) {
        console.error('Error loading products:', error);
    }
}

// دالة عرض المنتجات
function renderProducts(products) {
    const productsGrid = document.getElementById('productsGrid');
    productsGrid.innerHTML = '';

    products.forEach(product => {
        productsGrid.innerHTML += `
            <div class="product-card" data-category="${product.category}" data-code="${product.code}">
                <!-- قالب المنتج -->
            </div>
        `;
    });
}

// دالة إضافة منتج
async function addProduct() {
    const productData = {
        name: document.getElementById('productName').value,
        // باقي بيانات المنتج
    };

    try {
        await fetch('/api/products', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(productData)
        });
        loadProducts();
    } catch (error) {
        console.error('Error adding product:', error);
    }
}

// تحميل المنتجات عند بدء التشغيل
document.addEventListener('DOMContentLoaded', loadProducts);