require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const path = require('path');
const app = express();
const PORT = process.env.PORT || 3000;

// نموذج المنتج
const productSchema = new mongoose.Schema({
    name: String,
    code: String,
    category: String,
    price: Number,
    image: String,
    desc: String
});
const Product = mongoose.model('Product', productSchema);

// Middleware
app.use(express.json());
app.use(express.static(path.join(__dirname, '../public')));

// Routes
app.get('/api/products', async (req, res) => {
    try {
        const products = await Product.find();
        res.json(products);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.post('/api/products', async (req, res) => {
    try {
        const product = new Product(req.body);
        await product.save();
        res.status(201).json(product);
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
});

// الاتصال بقاعدة البيانات وتشغيل الخادم
mongoose.connect(process.env.MONGODB_URI)
    .then(() => app.listen(PORT, () => 
        console.log(`Server running on http://localhost:${PORT}`)))
    .catch(err => console.error('Database connection error:', err));