async function loadProducts() {
  const response = await fetch('/api/products');
  const products = await response.json();
  // عرض المنتجات في الواجهة
}

async function addProduct() {
  const productData = {
    name: document.getElementById('productName').value,
    code: document.getElementById('productCode').value,
    category: document.getElementById('productCategory').value,
    price: document.getElementById('productPrice').value,
    image: document.getElementById('productImage').value,
    desc: document.getElementById('productDesc').value
  };

  await fetch('/api/products', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(productData)
  });

  loadProducts(); // تحديث القائمة
}