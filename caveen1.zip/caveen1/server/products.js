const pool = require('./db');

async function createTable() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS products (
      id SERIAL PRIMARY KEY,
      code VARCHAR(50) UNIQUE NOT NULL,
      name VARCHAR(100) NOT NULL,
      category VARCHAR(50) NOT NULL,
      price INTEGER NOT NULL,
      image TEXT NOT NULL,
      description TEXT,
      created_at TIMESTAMP DEFAULT NOW()
    )
  `);
}

async function getAllProducts() {
  const res = await pool.query('SELECT * FROM products');
  return res.rows;
}

async function addProduct(product) {
  const query = `
    INSERT INTO products (code, name, category, price, image, description)
    VALUES ($1, $2, $3, $4, $5, $6)
    RETURNING *
  `;
  const values = [
    product.code,
    product.name,
    product.category,
    product.price,
    product.image,
    product.desc
  ];
  const res = await pool.query(query, values);
  return res.rows[0];
}

module.exports = { createTable, getAllProducts, addProduct };